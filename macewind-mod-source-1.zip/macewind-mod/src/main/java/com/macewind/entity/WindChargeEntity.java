package com.macewind.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import com.macewind.MaceWindMod;

public class WindChargeEntity extends ThrownItemEntity {

    // Knockback radius of the wind burst
    private static final double BURST_RADIUS = 3.0;
    // Upward force of the wind burst
    private static final double BURST_UP = 0.8;
    // Horizontal force of the wind burst
    private static final double BURST_HORIZONTAL = 1.2;

    public WindChargeEntity(EntityType<? extends WindChargeEntity> type, World world) {
        super(type, world);
    }

    public WindChargeEntity(EntityType<? extends WindChargeEntity> type, PlayerEntity thrower, World world) {
        super(type, thrower, world);
    }

    @Override
    protected Item getDefaultItem() {
        return MaceWindMod.WIND_CHARGE;
    }

    @Override
    public void tick() {
        super.tick();
        // Spawn trail particles
        if (world.isClient) {
            world.addParticle(ParticleTypes.CLOUD,
                    getX(), getY(), getZ(),
                    -getVelocity().x * 0.2, -getVelocity().y * 0.2, -getVelocity().z * 0.2);
        }
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        super.onCollision(hitResult);
        if (!world.isClient) {
            explode(hitResult);
            this.remove();
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult entityHitResult) {
        // Direct hit — apply extra knockback to hit entity
        Entity hit = entityHitResult.getEntity();
        Vec3d velocity = this.getVelocity().normalize();
        hit.setVelocity(velocity.x * BURST_HORIZONTAL, BURST_UP, velocity.z * BURST_HORIZONTAL);
        if (hit instanceof LivingEntity) {
            ((LivingEntity) hit).velocityModified = true;
        }
    }

    @Override
    protected void onBlockHit(BlockHitResult blockHitResult) {
        // Burst on block hit — handled in explode()
    }

    /**
     * Creates a wind burst at the impact point.
     * Knocks back all nearby entities and spawns visual/sound effects.
     */
    private void explode(HitResult hitResult) {
        Vec3d pos = hitResult.getPos();
        ServerWorld serverWorld = (ServerWorld) world;

        // Visual burst: cloud + sweep particles
        serverWorld.spawnParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z,
                30, 1.2, 0.6, 1.2, 0.08);
        serverWorld.spawnParticles(ParticleTypes.POOF, pos.x, pos.y, pos.z,
                20, 0.8, 0.4, 0.8, 0.12);
        serverWorld.spawnParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y + 0.5, pos.z,
                5, 0.5, 0.3, 0.5, 0.0);

        // Sound
        world.playSound(null, pos.x, pos.y, pos.z,
                SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.2f, 0.6f);
        world.playSound(null, pos.x, pos.y, pos.z,
                SoundEvents.ITEM_ELYTRA_FLYING, SoundCategory.PLAYERS, 0.8f, 1.6f);

        // Knockback all nearby living entities
        Entity owner = this.getOwner();
        world.getEntities(this, getBoundingBox().expand(BURST_RADIUS)).forEach(entity -> {
            if (entity instanceof LivingEntity && entity != owner) {
                Vec3d diff = entity.getPos().subtract(pos);
                double dist = diff.length();
                if (dist < BURST_RADIUS && dist > 0) {
                    // Strength falls off with distance
                    double strength = 1.0 - (dist / BURST_RADIUS);
                    Vec3d knockback = diff.normalize()
                            .multiply(BURST_HORIZONTAL * strength)
                            .add(0, BURST_UP * strength, 0);
                    entity.setVelocity(entity.getVelocity().add(knockback));
                    ((LivingEntity) entity).velocityModified = true;
                }
            }
        });

        // Boost the thrower upward if they're close to the blast (like in 1.21)
        if (owner instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) owner;
            double dist = player.getPos().distanceTo(pos);
            if (dist <= BURST_RADIUS + 1.0) {
                double strength = 1.0 - (dist / (BURST_RADIUS + 1.0));
                player.setVelocity(player.getVelocity().add(0, 1.4 * strength, 0));
                player.velocityModified = true;
            }
        }
    }
}
