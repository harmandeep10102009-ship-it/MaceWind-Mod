package com.macewind;

import com.macewind.entity.WindChargeEntity;
import com.macewind.item.MaceItem;
import com.macewind.item.WindChargeItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class MaceWindMod implements ModInitializer {

    public static final String MOD_ID = "macewind";

    // Items
    public static final Item BREEZE_ROD = new Item(new Item.Settings().group(ItemGroup.COMBAT));
    public static final Item MACE = new MaceItem(new Item.Settings().group(ItemGroup.COMBAT).maxCount(1).maxDamage(250));
    public static final Item WIND_CHARGE = new WindChargeItem(new Item.Settings().group(ItemGroup.COMBAT).maxCount(16));

    // Entity type for wind charge projectile
    public static EntityType<WindChargeEntity> WIND_CHARGE_ENTITY;

    @Override
    public void onInitialize() {
        // Register items
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "breeze_rod"), BREEZE_ROD);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "mace"), MACE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "wind_charge"), WIND_CHARGE);

        // Register entity
        WIND_CHARGE_ENTITY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "wind_charge"),
            FabricEntityTypeBuilder.<WindChargeEntity>create(SpawnGroup.MISC, WindChargeEntity::new)
                .dimensions(EntityDimensions.fixed(0.3125f, 0.3125f))
                .build()
        );

        System.out.println("[MaceWind] Mace and Wind Charge mod loaded!");
    }
}
