package com.macewind.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class MaceItem extends Item {

    // Base attack damage of the mace
    public static final float BASE_DAMAGE = 6.0f;
    // Bonus damage per block fallen (mimics 1.21 behavior)
    public static final float DAMAGE_PER_BLOCK = 0.5f;
    // Heavy smash threshold: player must fall at least this many blocks
    public static final float SMASH_THRESHOLD = 1.5f;

    public MaceItem(Settings settings) {
        super(settings);
    }

    /**
     * Called when the player attacks an entity.
     * We use a mixin to inject bonus fall damage into the attack.
     * This method handles the smash attack visual/sound effects.
     */
    public static float getBonusDamage(PlayerEntity player) {
        float fallDistance = player.fallDistance;
        if (fallDistance >= SMASH_THRESHOLD) {
            return fallDistance * DAMAGE_PER_BLOCK;
        }
        return 0.0f;
    }

    public static boolean isSmashAttack(PlayerEntity player) {
        return player.fallDistance >= SMASH_THRESHOLD && !player.isOnGround();
    }

    /**
     * Applies smash attack effects: particles, sound, and upward bounce for nearby mobs.
     */
    public static void applySmashEffects(PlayerEntity attacker, LivingEntity target, World world) {
        if (!(world instanceof ServerWorld)) return;
        ServerWorld serverWorld = (ServerWorld) world;

        Vec3d pos = target.getPos();

        // Spawn wind burst particles around the target
        serverWorld.spawnParticles(ParticleTypes.CLOUD, pos.x, pos.y + 0.5, pos.z,
                20, 1.0, 0.5, 1.0, 0.1);
        serverWorld.spawnParticles(ParticleTypes.POOF, pos.x, pos.y + 0.5, pos.z,
                15, 0.8, 0.4, 0.8, 0.15);

        // Play smash sound
        world.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6f, 1.4f);
        world.playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 0.8f);

        // Bounce nearby entities upward (wind burst effect)
        double radius = 2.5;
        world.getEntities(attacker, target.getBoundingBox().expand(radius)).forEach(entity -> {
            if (entity instanceof LivingEntity && entity != attacker) {
                Vec3d diff = entity.getPos().subtract(pos).normalize();
                entity.setVelocity(diff.x * 1.2, 1.5, diff.z * 1.2);
                ((LivingEntity) entity).velocityModified = true;
            }
        });

        // Reset attacker's fall distance after smash
        attacker.fallDistance = 0;
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damage(1, attacker, e -> e.sendEquipmentBreakStatus(attacker.getActiveHand() == net.minecraft.util.Hand.MAIN_HAND
                ? net.minecraft.entity.EquipmentSlot.MAINHAND
                : net.minecraft.entity.EquipmentSlot.OFFHAND));
        return true;
    }

    @Override
    public boolean canRepair(ItemStack stack, ItemStack ingredient) {
        // Can be repaired with breeze rods
        return ingredient.getItem() == com.macewind.MaceWindMod.BREEZE_ROD;
    }
}
