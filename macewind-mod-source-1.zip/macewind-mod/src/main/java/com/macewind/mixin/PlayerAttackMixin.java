package com.macewind.mixin;

import com.macewind.item.MaceItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public abstract class PlayerAttackMixin {

    private float macewind_bonusDamage = 0f;
    private boolean macewind_isSmash = false;

    /**
     * Before the attack: check if holding mace and capture fall distance for bonus damage.
     */
    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttackHead(Entity target, CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        ItemStack mainHand = self.getMainHandStack();

        macewind_bonusDamage = 0f;
        macewind_isSmash = false;

        if (mainHand.getItem() instanceof MaceItem) {
            macewind_bonusDamage = MaceItem.getBonusDamage(self);
            macewind_isSmash = MaceItem.isSmashAttack(self);
        }
    }

    /**
     * Modify the damage value applied in the attack to add mace fall bonus.
     */
    @ModifyVariable(
        method = "attack",
        at = @At(value = "STORE", ordinal = 0),
        ordinal = 0
    )
    private float modifyAttackDamage(float damage) {
        return damage + macewind_bonusDamage;
    }

    /**
     * After a successful hit: if it was a smash attack, apply wind burst effects.
     */
    @Inject(
        method = "attack",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", shift = At.Shift.AFTER)
    )
    private void onAttackHit(Entity target, CallbackInfo ci) {
        if (!macewind_isSmash) return;
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (target instanceof LivingEntity) {
            MaceItem.applySmashEffects(self, (LivingEntity) target, self.world);
        }
    }
}
