# Mace & Wind Charge Mod — Fabric 1.16.5

Backports the **Mace** and **Wind Charge** from Minecraft 1.21 to 1.16.5!

---

## Items

### 🔨 Mace
A heavy weapon with a unique **smash attack**.
- **Base damage:** 6
- **Smash attack:** Deals bonus damage based on how far you fell before hitting. Each block of fall = +0.5 damage
- **Wind burst:** On a smash hit, nearby mobs are blasted upward
- **Durability:** 250 uses
- **Repair material:** Breeze Rod

**Crafting:**
```
 B
 R
 R
```
- `B` = Heavy Weighted Pressure Plate
- `R` = Breeze Rod

---

### 💨 Wind Charge
A throwable item that explodes on impact with a burst of wind.
- Right-click to throw
- Knocks back nearby entities in a 3-block radius
- Gives the **thrower a slight upward boost** if nearby (great for mobility!)
- Stacks to 16

**Crafting (shapeless):**
- 1× Breeze Rod + 1× Gunpowder + 1× Feather = **3× Wind Charge**

---

### 🌿 Breeze Rod
The core crafting material. Obtain it from the creative inventory or add your own loot table drop (e.g., from Blazes as a placeholder until you add a Breeze mob).

---

## Setup & Build

**Requirements:**
- Java 8+
- Gradle 7+

**Build the mod:**
```bash
./gradlew build
```

The compiled `.jar` will be in `build/libs/`. Drop it into your Fabric 1.16.5 `mods/` folder.

---

## Textures

Placeholder textures are needed for:
- `assets/macewind/textures/item/mace.png`
- `assets/macewind/textures/item/wind_charge.png`
- `assets/macewind/textures/item/breeze_rod.png`

You can use the official 1.21 textures from the Minecraft resource pack, or create your own 16×16 PNG files.

---

## Notes

- The Mace's smash attack uses a **Mixin** to inject into `PlayerEntity#attack`, which is standard Fabric practice.
- Wind Charge entity has fall-off knockback — closer entities get hit harder.
- The player who throws a Wind Charge gets a boost if they're within ~4 blocks of the impact, enabling aerial combos just like 1.21.
